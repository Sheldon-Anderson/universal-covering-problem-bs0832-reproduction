# v0.8.6 true Arb/local tensor port v1 report

## Status

- status: `true_arb_and_local_tensor_port_v1_generated_not_theorem_proof`
- target: `0.832`
- stress target: `0.83201`
- theorem ready: `False`

## Main counts

- true directed interval port rows: `41261`
- true directed interval failures vs 0.832: `0`
- true local tensor member rows: `8751`
- true local tensor failures vs 0.832: `0`
- h004 boundary replay rows: `282`
- h004 boundary replay failures: `0`

## Boundary

This is not a theorem-level proof. It is a v1 candidate port using Decimal/guarded outward-style replay. External Arb/outward-rounded kernels and true local tensor proof artifacts remain required.
