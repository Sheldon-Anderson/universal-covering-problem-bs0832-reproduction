# BS0832 v0.10.4 one-command final decision replay plan (candidate)
# This is a replay plan for theorem package v13 final-decision attempt.
# It does not by itself prove the theorem.
powershell -ExecutionPolicy Bypass -File .\scripts\run_v104_local.ps1
