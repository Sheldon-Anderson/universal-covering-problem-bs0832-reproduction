# BS0832 v0.10.4 Final Decision Replay Plan

Run `powershell -ExecutionPolicy Bypass -File .\scripts\run_v104_local.ps1`.
