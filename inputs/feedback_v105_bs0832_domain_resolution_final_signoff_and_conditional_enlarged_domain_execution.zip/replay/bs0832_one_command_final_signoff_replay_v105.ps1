# v0.10.5 one-command final signoff replay plan
# Run from project root after placing required feedback zips.
powershell -ExecutionPolicy Bypass -File .\scripts\run_v105_local.ps1
