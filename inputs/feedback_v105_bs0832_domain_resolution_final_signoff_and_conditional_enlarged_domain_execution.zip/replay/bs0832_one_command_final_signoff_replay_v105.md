# v0.10.5 one-command replay

Run `powershell -ExecutionPolicy Bypass -File .\scripts\run_v105_local.ps1`.
