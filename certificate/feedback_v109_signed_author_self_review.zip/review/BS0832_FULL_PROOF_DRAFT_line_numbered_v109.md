L0001: # BS0832 full proof draft candidate
L0002: 
L0003: ## 1. Setup
L0004: 
L0005: We use the Brass--Sharifi three-test-set normalization with parameter vector
L0006: `v = (rho, x3, y3, x5, y5)`.  The disk is fixed at the origin, the equilateral
L0007: triangle is translated, and the regular pentagon is rotated and translated.  The
L0008: quantity to be bounded is the convex-hull area `A(v)`.
L0009: 
L0010: ## 2. Domain route
L0011: 
L0012: The final candidate proof package uses Branch B.  Branch A symbolic
L0013: range-reduction remains unclosed.  Branch B is not a new theorem statement by
L0014: itself; it is the adopted candidate replay route that connects the admissible
L0015: parameter domain to the adaptive terminal-route ledger.
L0016: 
L0017: ## 3. Adaptive ledger and terminal route coverage
L0018: 
L0019: The v096/v097/v107 chain records `356816`
L0020: terminal routes.  The route replay has `0`
L0021: failures against the BS0832 target.  The route-family dispatch is:
L0022: 
L0023: ```json
L0024: {
L0025:   "h004_bridge_containment": 69,
L0026:   "true_directed_interval_port_v1": 338367,
L0027:   "true_local_tensor_port_v1": 18380
L0028: }
L0029: ```
L0030: 
L0031: ## 4. Directed interval route
L0032: 
L0033: The directed interval route is certified by the v086/v097/v105/v107 candidate
L0034: chain.  The directed component has `41261` rows,
L0035: `0` failures against `0.832`, and a
L0036: v105 final-signoff minimum margin of `0.00000430727642248555227`.
L0037: The external-Arb/outward-rounded theorem kernel remains a final-review accepted
L0038: candidate rather than a machine-formalized theorem.
L0039: 
L0040: ## 5. Local tensor route
L0041: 
L0042: The local tensor route is certified by `8751` members in
L0043: `125` packages, with
L0044: `0` failures against `0.832`.  The tensor
L0045: domination theorem remains a final-review accepted candidate rather than a
L0046: machine-formalized theorem.
L0047: 
L0048: ## 6. h004 bridge route
L0049: 
L0050: The h=0.004 bridge route uses the frozen v050 local package and the v097/v107
L0051: replay binding.  It has `282` witness rows and
L0052: `0` failures.
L0053: 
L0054: ## 7. Aggregation
L0055: 
L0056: For each terminal route, the route dispatch sends the route to exactly one of the
L0057: three accepted candidate proof components: directed interval, local tensor, or
L0058: h004 bridge.  Each component supplies a candidate lower bound at or above
L0059: `0.832` after its recorded guards.  Therefore the v0.10.8 package is a
L0060: reproduction-complete candidate for the old Brass--Sharifi lower bound
L0061: `A(v) >= 0.832` over the Branch-B replay domain.
L0062: 
L0063: ## 8. Boundary and non-claims
L0064: 
L0065: This draft does not prove `0.83201`.  The v107/v108 chain preserves
L0066: `8` stress failures for `0.83201`; these
L0067: are isolated into the v0.11.x repair queue and are not included in the BS0832
L0068: claim.  This draft also keeps the theorem-ready flag false; final external/human
L0069: signoff is still required before theorem-level language is appropriate.
