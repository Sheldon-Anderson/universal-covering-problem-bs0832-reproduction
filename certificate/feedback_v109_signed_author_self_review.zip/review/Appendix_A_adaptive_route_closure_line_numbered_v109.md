L0001: # Appendix A: adaptive route closure
L0002: 
L0003: - Input artifacts: v096 full adaptive ledger, adaptive_full_ledger_export_v096, v097 terminal route replay, v107 hash audit.
L0004: - Parent-child edges: `379192`.
L0005: - Endpoint rows: `568788`.
L0006: - Terminal route rows: `356816`.
L0007: - Terminal replay failures: `0`.
L0008: - Candidate status: complete for reproduction-closure package.
