# v109 reviewer signoff template

This template is for an external/human review of the BS0832 final signoff packet.
It is not needed for the default v109 run.  To activate the signed-review mode,
fill `reviewer_signoff_v109.json` according to `review/signoff_schema_v109.json`
and rerun v109 with:

```powershell
--external-signoff-json .eviewer_signoff_v109.json
```

Expected reviewed feedback SHA256:

```text
93b8d5d755f586912bc9a5c710e1571777c32939eab94dc0cfccaf69f4aadea6
```

Blocking obligations to accept:

```text
OB-A-001, OB-A-002, OB-A-003, OB-B-001, OB-B-002, OB-B-003, OB-B-004, OB-B-005, OB-C-001, OB-C-002, OB-C-003, OB-D-001, OB-E-001, OB-E-002, OB-E-003, OB-F-001, OB-F-002, OB-F-003, OB-F-004
```

Blocking formalization gaps to accept/adjudicate:

```text
FG1, FG2, FG3, FG4
```

Allowed global decisions:

```text
accepted, accepted_with_minor_notes, needs_revision, rejected
```

The default safe behavior is to keep `theorem_ready=false`.  Even with a valid
signoff JSON, v109 sets `theorem_ready_signed_candidate=true` but keeps
`theorem_ready=false` unless the command-line flag
`--allow-theorem-ready-on-signed-review` is explicitly supplied.
