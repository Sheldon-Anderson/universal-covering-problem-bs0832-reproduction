L0001: # BS0832 theorem statement candidate
L0002: 
L0003: Let
L0004: 
L0005: ```text
L0006: v = (rho, x3, y3, x5, y5)
L0007: ```
L0008: 
L0009: be an admissible Brass--Sharifi three-test-set placement in the adopted
L0010: Branch-B replay domain: the unit-diameter disk is fixed at the origin, the
L0011: unit-diameter equilateral triangle is translated by `(x3, y3)`, and the
L0012: unit-diameter regular pentagon is rotated by `rho` and translated by `(x5, y5)`.
L0013: Let
L0014: 
L0015: ```text
L0016: A(v) = area(conv(C union (T + (x3, y3)) union (R_rho P5 + (x5, y5))))
L0017: ```
L0018: 
L0019: be the convex-hull area functional used throughout the certificate chain.
L0020: 
L0021: **Theorem statement candidate.** For every admissible placement `v` covered by
L0022: the Branch-B replay domain route, the candidate certificate chain supports
L0023: 
L0024: ```text
L0025: A(v) >= 0.832.
L0026: ```
L0027: 
L0028: This v0.10.8 package is a reproduction-complete candidate and final signoff
L0029: package.  It does not assert a true theorem-ready flag, does not assert a 0.83201 lower
L0030: bound, and does not claim that the Branch-A symbolic range-reduction proof is
L0031: closed.
