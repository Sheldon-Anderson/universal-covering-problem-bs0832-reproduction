L0001: # BS0832 proof overview candidate
L0002: 
L0003: The proof-manuscript candidate follows the Brass--Sharifi three-test-set route
L0004: with parameters `(rho, x3, y3, x5, y5)`.  The v0.10.8 package converts the
L0005: v0.10.7 artifact release candidate into a structured proof manuscript candidate.
L0006: 
L0007: The argument is organized as follows.
L0008: 
L0009: 1. **Adaptive route closure.** The adaptive ledger contains
L0010:    `379192` parent-child edges,
L0011:    `568788` endpoint rows, and
L0012:    `356816` terminal routes.  The v107
L0013:    full hash audit and fresh replay reported no terminal route failures.
L0014: 2. **Route dispatch.** Terminal routes split into three candidate proof routes:
L0015:    `{"h004_bridge_containment": 69, "true_directed_interval_port_v1": 338367, "true_local_tensor_port_v1": 18380}`.
L0016: 3. **Directed interval route.** The directed/external-Arb candidate kernel binds
L0017:    `41261` rows with zero failures against `0.832` and
L0018:    final signoff minimum margin `0.00000430727642248555227`.
L0019: 4. **Local tensor route.** The tensor candidate kernel binds
L0020:    `8751` members across `125`
L0021:    packages with zero failures against `0.832`.
L0022: 5. **h004 bridge route.** The frozen h=0.004 local package binds
L0023:    `282` bridge witnesses with zero failures.
L0024: 6. **Domain route.** Branch A remains unclosed.  The theorem-candidate package
L0025:    adopts the Branch-B enlarged-domain replay route, accepted as a final-review
L0026:    candidate in v107.
L0027: 
L0028: Boundary: this is a proof-manuscript candidate for reproducing the old `0.832`
L0029: lower bound.  It preserves `theorem_ready=false` and isolates the `0.83201`
L0030: stress failures for a later v0.11.x repair branch.
