L0001: # Appendix D: h004 bridge
L0002: 
L0003: - Input artifacts: v050 frozen h004 package, v097 h004 replay, v107 h004 hash audit.
L0004: - h004 witness rows: `282`.
L0005: - h004 failures: `0`.
L0006: - Candidate status: complete for reproduction-closure package.
