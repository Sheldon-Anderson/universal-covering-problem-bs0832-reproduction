L0001: # Appendix E: Branch-B domain route
L0002: 
L0003: - Branch A symbolic range reduction: not closed.
L0004: - Adopted candidate domain route: Branch-B enlarged-domain replay.
L0005: - Terminal routes covered: `356816`.
L0006: - Route families: `{"h004_bridge_containment": 69, "true_directed_interval_port_v1": 338367, "true_local_tensor_port_v1": 18380}`.
L0007: - Candidate status: Branch-B final acceptance candidate from v107.
