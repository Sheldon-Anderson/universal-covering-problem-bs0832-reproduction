L0001: # Appendix B: directed interval/external-Arb kernel
L0002: 
L0003: - Input artifacts: v086 directed kernel, v097 directed replay, v105 final signoff, v107 G2 final review.
L0004: - Directed rows: `41261`.
L0005: - Failures against 0.832: `0`.
L0006: - Final signoff minimum margin: `0.00000430727642248555227`.
L0007: - Duplicate source identifiers: `608`; treated as multiset-bound ordered occurrences, not unique identifiers.
L0008: - Boundary: external-Arb kernel review accepted candidate; not machine-formalized theorem.
