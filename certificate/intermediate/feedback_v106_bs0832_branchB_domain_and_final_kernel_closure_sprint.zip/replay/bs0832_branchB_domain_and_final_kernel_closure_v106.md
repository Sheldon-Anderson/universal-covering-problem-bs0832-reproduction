# v0.10.6 Branch-B domain and final-kernel closure sprint

Run `powershell -ExecutionPolicy Bypass -File .\scripts\run_v106_local.ps1`.

Strict boundary: this is a candidate-level dry-freeze package, not theorem proof.
