# v0.10.6 Branch-B domain and final-kernel closure sprint
# Run from project root after placing required feedback zips.
powershell -ExecutionPolicy Bypass -File .\scripts\run_v106_local.ps1
