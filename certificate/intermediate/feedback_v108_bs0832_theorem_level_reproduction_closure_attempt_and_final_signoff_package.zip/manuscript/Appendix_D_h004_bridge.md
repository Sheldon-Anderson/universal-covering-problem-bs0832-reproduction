# Appendix D: h004 bridge

- Input artifacts: v050 frozen h004 package, v097 h004 replay, v107 h004 hash audit.
- h004 witness rows: `282`.
- h004 failures: `0`.
- Candidate status: complete for reproduction-closure package.
