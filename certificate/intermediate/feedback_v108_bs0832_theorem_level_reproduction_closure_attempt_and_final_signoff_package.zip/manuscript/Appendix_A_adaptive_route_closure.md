# Appendix A: adaptive route closure

- Input artifacts: v096 full adaptive ledger, adaptive_full_ledger_export_v096, v097 terminal route replay, v107 hash audit.
- Parent-child edges: `379192`.
- Endpoint rows: `568788`.
- Terminal route rows: `356816`.
- Terminal replay failures: `0`.
- Candidate status: complete for reproduction-closure package.
