# BS0832 full proof draft candidate

## 1. Setup

We use the Brass--Sharifi three-test-set normalization with parameter vector
`v = (rho, x3, y3, x5, y5)`.  The disk is fixed at the origin, the equilateral
triangle is translated, and the regular pentagon is rotated and translated.  The
quantity to be bounded is the convex-hull area `A(v)`.

## 2. Domain route

The final candidate proof package uses Branch B.  Branch A symbolic
range-reduction remains unclosed.  Branch B is not a new theorem statement by
itself; it is the adopted candidate replay route that connects the admissible
parameter domain to the adaptive terminal-route ledger.

## 3. Adaptive ledger and terminal route coverage

The v096/v097/v107 chain records `356816`
terminal routes.  The route replay has `0`
failures against the BS0832 target.  The route-family dispatch is:

```json
{
  "h004_bridge_containment": 69,
  "true_directed_interval_port_v1": 338367,
  "true_local_tensor_port_v1": 18380
}
```

## 4. Directed interval route

The directed interval route is certified by the v086/v097/v105/v107 candidate
chain.  The directed component has `41261` rows,
`0` failures against `0.832`, and a
v105 final-signoff minimum margin of `0.00000430727642248555227`.
The external-Arb/outward-rounded theorem kernel remains a final-review accepted
candidate rather than a machine-formalized theorem.

## 5. Local tensor route

The local tensor route is certified by `8751` members in
`125` packages, with
`0` failures against `0.832`.  The tensor
domination theorem remains a final-review accepted candidate rather than a
machine-formalized theorem.

## 6. h004 bridge route

The h=0.004 bridge route uses the frozen v050 local package and the v097/v107
replay binding.  It has `282` witness rows and
`0` failures.

## 7. Aggregation

For each terminal route, the route dispatch sends the route to exactly one of the
three accepted candidate proof components: directed interval, local tensor, or
h004 bridge.  Each component supplies a candidate lower bound at or above
`0.832` after its recorded guards.  Therefore the v0.10.8 package is a
reproduction-complete candidate for the old Brass--Sharifi lower bound
`A(v) >= 0.832` over the Branch-B replay domain.

## 8. Boundary and non-claims

This draft does not prove `0.83201`.  The v107/v108 chain preserves
`8` stress failures for `0.83201`; these
are isolated into the v0.11.x repair queue and are not included in the BS0832
claim.  This draft also keeps the theorem-ready flag false; final external/human
signoff is still required before theorem-level language is appropriate.
