# Appendix B: directed interval/external-Arb kernel

- Input artifacts: v086 directed kernel, v097 directed replay, v105 final signoff, v107 G2 final review.
- Directed rows: `41261`.
- Failures against 0.832: `0`.
- Final signoff minimum margin: `0.00000430727642248555227`.
- Duplicate source identifiers: `608`; treated as multiset-bound ordered occurrences, not unique identifiers.
- Boundary: external-Arb kernel review accepted candidate; not machine-formalized theorem.
