# Appendix E: Branch-B domain route

- Branch A symbolic range reduction: not closed.
- Adopted candidate domain route: Branch-B enlarged-domain replay.
- Terminal routes covered: `356816`.
- Route families: `{"h004_bridge_containment": 69, "true_directed_interval_port_v1": 338367, "true_local_tensor_port_v1": 18380}`.
- Candidate status: Branch-B final acceptance candidate from v107.
