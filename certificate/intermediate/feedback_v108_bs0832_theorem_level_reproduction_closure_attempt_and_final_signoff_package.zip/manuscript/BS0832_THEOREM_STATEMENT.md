# BS0832 theorem statement candidate

Let

```text
v = (rho, x3, y3, x5, y5)
```

be an admissible Brass--Sharifi three-test-set placement in the adopted
Branch-B replay domain: the unit-diameter disk is fixed at the origin, the
unit-diameter equilateral triangle is translated by `(x3, y3)`, and the
unit-diameter regular pentagon is rotated by `rho` and translated by `(x5, y5)`.
Let

```text
A(v) = area(conv(C union (T + (x3, y3)) union (R_rho P5 + (x5, y5))))
```

be the convex-hull area functional used throughout the certificate chain.

**Theorem statement candidate.** For every admissible placement `v` covered by
the Branch-B replay domain route, the candidate certificate chain supports

```text
A(v) >= 0.832.
```

This v0.10.8 package is a reproduction-complete candidate and final signoff
package.  It does not assert a true theorem-ready flag, does not assert a 0.83201 lower
bound, and does not claim that the Branch-A symbolic range-reduction proof is
closed.
