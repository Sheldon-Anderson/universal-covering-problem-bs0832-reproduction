# BS0832 proof overview candidate

The proof-manuscript candidate follows the Brass--Sharifi three-test-set route
with parameters `(rho, x3, y3, x5, y5)`.  The v0.10.8 package converts the
v0.10.7 artifact release candidate into a structured proof manuscript candidate.

The argument is organized as follows.

1. **Adaptive route closure.** The adaptive ledger contains
   `379192` parent-child edges,
   `568788` endpoint rows, and
   `356816` terminal routes.  The v107
   full hash audit and fresh replay reported no terminal route failures.
2. **Route dispatch.** Terminal routes split into three candidate proof routes:
   `{"h004_bridge_containment": 69, "true_directed_interval_port_v1": 338367, "true_local_tensor_port_v1": 18380}`.
3. **Directed interval route.** The directed/external-Arb candidate kernel binds
   `41261` rows with zero failures against `0.832` and
   final signoff minimum margin `0.00000430727642248555227`.
4. **Local tensor route.** The tensor candidate kernel binds
   `8751` members across `125`
   packages with zero failures against `0.832`.
5. **h004 bridge route.** The frozen h=0.004 local package binds
   `282` bridge witnesses with zero failures.
6. **Domain route.** Branch A remains unclosed.  The theorem-candidate package
   adopts the Branch-B enlarged-domain replay route, accepted as a final-review
   candidate in v107.

Boundary: this is a proof-manuscript candidate for reproducing the old `0.832`
lower bound.  It preserves `theorem_ready=false` and isolates the `0.83201`
stress failures for a later v0.11.x repair branch.
