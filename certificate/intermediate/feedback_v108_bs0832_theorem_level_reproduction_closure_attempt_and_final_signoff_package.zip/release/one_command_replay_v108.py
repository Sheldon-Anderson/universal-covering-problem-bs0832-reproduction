from pathlib import Path
import subprocess, sys
cmd = [sys.executable, str(Path('scripts') / '86_v108_bs0832_theorem_level_reproduction_closure_attempt_and_final_signoff_package.py'), '--run-id', 'v108', '--v107-feedback-zip', 'feedback_v107_bs0832_final_theorem_release_candidate_and_independent_review_bundle.zip']
raise SystemExit(subprocess.call(cmd))
