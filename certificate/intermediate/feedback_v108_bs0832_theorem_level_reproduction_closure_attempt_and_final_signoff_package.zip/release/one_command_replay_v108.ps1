# v0.10.8 BS0832 theorem-level reproduction closure attempt and final signoff package
# Run from project root after placing the required v107 feedback zip.
python .\scripts\86_v108_bs0832_theorem_level_reproduction_closure_attempt_and_final_signoff_package.py `
  --run-id v108 `
  --v107-feedback-zip .\feedback_v107_bs0832_final_theorem_release_candidate_and_independent_review_bundle.zip `
  --v106-feedback-zip .\feedback_v106_bs0832_branchB_domain_and_final_kernel_closure_sprint.zip `
  --v105-feedback-zip .\feedback_v105_bs0832_domain_resolution_final_signoff_and_conditional_enlarged_domain_execution.zip `
  --v096-feedback-zip .\feedback_v096_adaptive_full_ledger_rerun_executor.zip `
  --adaptive-full-ledger-zip .\adaptive_full_ledger_export_v096.zip `
  --v097-feedback-zip .\feedback_v097_external_proof_replay_and_proof_package_v6_audit.zip `
  --v086-feedback-zip .\feedback_v086_true_arb_and_local_tensor_port_v1.zip `
  --v050-feedback-zip .\feedback_v050_h004_local_proof_freeze_main.zip `
  --log-level INFO
