# Appendix E: Branch B domain route

- Branch A symbolic range reduction remains unclosed.
- Branch B enlarged-domain replay is the adopted candidate domain route.
- terminal route replay rows: 356816
- terminal route replay failures: 0
- final-review accepted candidate: True
