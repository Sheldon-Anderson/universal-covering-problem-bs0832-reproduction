# Appendix A: adaptive full ledger / terminal route closure

- parent-child edges observed: 379192
- terminal routes observed: 356816
- route counts: {"h004_bridge_containment": 69, "true_directed_interval_port_v1": 338367, "true_local_tensor_port_v1": 18380}
- final-review accepted candidate: True
