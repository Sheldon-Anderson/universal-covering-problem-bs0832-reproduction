# Appendix B: directed interval / external-Arb kernel

- directed rows observed: 41261
- directed failures vs 0.832: 0
- G2 v086 rows: 41261
- min margin v105 vs 0.832: 0.00000430727642248555227
- final-review accepted candidate: True
- formal theorem flag remains false; this checklist is for final review acceptance candidate only.
