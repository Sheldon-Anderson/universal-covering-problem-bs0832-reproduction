# BS0832 reproducibility

Run from the project root after placing the required feedback zips in the root.

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\run_v107_local.ps1
```

Expected feedback output:

```text
runs\v107\feedback_v107_bs0832_final_theorem_release_candidate_and_independent_review_bundle.zip
```

This run performs fresh replay from v096/v097/v086/v050/v105/v106 artifacts and
emits compact block-hash audits instead of huge per-row tables by default.
