# v0.10.7 BS0832 final theorem release-candidate and independent review bundle
# Run from project root after placing required feedback zips.
python .\scripts\85_v107_bs0832_final_theorem_release_candidate_and_independent_review_bundle.py `
  --run-id v107 `
  --v106-feedback-zip .\feedback_v106_bs0832_branchB_domain_and_final_kernel_closure_sprint.zip `
  --v105-feedback-zip .\feedback_v105_bs0832_domain_resolution_final_signoff_and_conditional_enlarged_domain_execution.zip `
  --v096-feedback-zip .\feedback_v096_adaptive_full_ledger_rerun_executor.zip `
  --adaptive-full-ledger-zip .\adaptive_full_ledger_export_v096.zip `
  --v097-feedback-zip .\feedback_v097_external_proof_replay_and_proof_package_v6_audit.zip `
  --v086-feedback-zip .\feedback_v086_true_arb_and_local_tensor_port_v1.zip `
  --v050-feedback-zip .\feedback_v050_h004_local_proof_freeze_main.zip `
  --decimal-precision 180 `
  --terminal-route-limit 0 `
  --directed-row-limit 0 `
  --tensor-member-limit 0 `
  --h004-witness-limit 0 `
  --accept-margin 0.0000001 `
  --route-hash-block-size 50000 `
  --directed-hash-block-size 10000 `
  --tensor-hash-block-size 2000 `
  --h004-hash-block-size 500 `
  --progress-interval 100000 `
  --log-level INFO
